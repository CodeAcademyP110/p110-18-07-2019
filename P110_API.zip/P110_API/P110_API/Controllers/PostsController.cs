﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using P110_API.Models;
using P110_API.DAL;
using Microsoft.EntityFrameworkCore;

namespace P110_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostsController : ControllerBase
    {
        private readonly ApiDbContext _context;

        public PostsController(ApiDbContext context)
        {
            _context = context;
        }

        // GET api/posts/
        [HttpGet]
        public ActionResult<IEnumerable<Post>> Get()
        {
            return _context.Posts.Include(p => p.Comments).ToList();

            #region Ignoring circular reference with Select
            //return _context.Posts.Include(p => p.Comments)
            //        .Select(p => new
            //        {
            //            p.Id,
            //            p.Title,
            //            p.Content,
            //            comments = p.Comments.Select(c => new
            //            {
            //                c.Id,
            //                c.Content
            //            }).ToList()
            //        }).ToList();
            #endregion
        }

        // GET api/posts/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Post>> Get(int id)
        {
            Post post = await _context.Posts.FindAsync(id);

            if (post == null)
                return NotFound();

            return post;
        }

        // POST: api/Posts
        [HttpPost]
        public async Task<ActionResult> Post(Post post)
        {
            await _context.Posts.AddAsync(post);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(Get), new { id = post.Id }, post);
        }

        //[HttpPost]
        //public ActionResult Post([FromBody] int number)
        //{
        //    return CreatedAtAction(nameof(Get), number);
        //}

        // PUT: api/Posts/5

        [HttpPut("{id}")]
        public async Task<ActionResult> Put(int id, Post post)
        {
            if (!_context.Posts.Any(p => p.Id == id)) return NotFound();

            if (id != post.Id) return BadRequest();

            Post postFromDb = await _context.Posts.FindAsync(id);

            postFromDb.Title = post.Title;
            postFromDb.Content = post.Content;

            //_context.Entry(post).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            Post post = await _context.Posts.FindAsync(id);

            if (post == null) return BadRequest();

            _context.Posts.Remove(post);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}

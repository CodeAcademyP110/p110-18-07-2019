﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using P110_API.Models;

namespace P110_API.DAL
{
    public class ApiDbContext : DbContext
    {
        public ApiDbContext(DbContextOptions<ApiDbContext> options) : base(options)
        {
        }

        public DbSet<Post> Posts { get; set; }
        public DbSet<Comment> Comments { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Post>().HasData(
                new Post { Id = 1, Title = "Resad, dunqus Resad", Content = "1 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum." },
                new Post { Id = 2, Title = "Kamil, zoku Kamil", Content = "2 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum." },
                new Post { Id = 3, Title = "Perviz, pacan Perviz", Content = "3 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum." }
            );

            modelBuilder.Entity<Comment>().HasData(
                new Comment { Id = 1, Content = "Comment 1 for new post", PostId = 2 },
                new Comment { Id = 2, Content = "Comment 2 for new post", PostId = 2 },
                new Comment { Id = 3, Content = "Comment 3 for new post", PostId = 3 },
                new Comment { Id = 4, Content = "Comment 4 for new post", PostId = 3 },
                new Comment { Id = 5, Content = "Comment 5 for new post", PostId = 4 },
                new Comment { Id = 6, Content = "Comment 6 for new post", PostId = 5 },
                new Comment { Id = 7, Content = "Comment 7 for new post", PostId = 3 },
                new Comment { Id = 8, Content = "Comment 8 for new post", PostId = 2 }
            );
        }
    }
}

﻿using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace P110_API.Models
{
    public class Post
    {
        public Post()
        {
            Comments = new HashSet<Comment>();
        }

        public int Id { get; set; }

        [Required, StringLength(100)]
        public string Title { get; set; }

        [Required]
        public string Content { get; set; }

        public virtual ICollection<Comment> Comments { get; set; }
    }
}
